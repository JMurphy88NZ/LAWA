library(shiny)

source("For_Andrew/simulate_trends_functions.R")


server <- function(input, output) {
  output$timeSeriesPlot <- renderPlot({
    total_length <- input$total_length
    time_series <- NULL
    
    if (input$series_type == "Cosine") {
      time_series <- generate_cosine_series(total_length, input$initial_amplitude, input$decay_rate, 
                                            input$num_peaks, input$phase_shift)
      
    } else if (input$series_type == "Linear Trend") {
      time_series <- generate_linear_trend(total_length, input$slope, input$intercept)
      
      
    } else if (input$series_type == "Level Shift With Ramp") {
      time_series <- level_shift_with_ramp(total_length, input$baseline_amp, input$amp_change, input$ramp_start, input$ramp_length, input$steepness )
    
    } else if (input$series_type == "Linex") {
      time_series <- generate_linex(total_length, input$amplitude, input$x_min, input$scale)
   
    } else if (input$series_type == "Gaussian"){
      time_series <- generate_gaussian(total_length, input$amplitude, input$centre, input$width)
    }
    
    # Plotting
    plot(1:total_length, time_series, type = "l", col = "blue", 
         ylab = "Value", xlab = "Time", 
         main = paste(input$series_type, "Time Series"))
    grid()
  })
}


