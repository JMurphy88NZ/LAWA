library(shiny)

ui <- fluidPage(
  titlePanel("Time Series Simulation"),
  
  sidebarLayout(
    sidebarPanel(
      selectInput("series_type", "Select Time Series Type:",
                  choices = c("Cosine", "Linear Trend", "Level Shift With Ramp","Linex", "Gaussian")),
      sliderInput("total_length", "Total Length of Time Series:", min = 1, max = 500, value = 200),
      
      conditionalPanel(
        condition = "input.series_type == 'Cosine'",
        sliderInput("initial_amplitude", "Initial Amplitude:", min = 0, max = 10, value = 5),
        sliderInput("decay_rate", "Decay Rate:", min = -1, max = 1, value = 0.01, step = 0.005),
        sliderInput("num_peaks", "Number of Peaks:", min = -5, max = 10, value = 3, step = 0.25),
        sliderInput("phase_shift", "Phase Shift (radians):", min = 0, max = 2 * pi, value = pi / 4),
      ),
      
      conditionalPanel(
        condition = "input.series_type == 'Linear Trend'",
        sliderInput("slope", "Slope:", min = -1, max = 1, value = 0.1, step = 0.01),
        sliderInput("intercept", "Intercept:", min = -10, max = 10, value = 0),
      ),
      

      conditionalPanel(
        condition = "input.series_type == 'Level Shift With Ramp'",
        sliderInput("baseline_amp", "Baseline Amplitude:", min = -5, max = 5, value = 0.3, step = 0.05),
        sliderInput("amp_change", "Amplitude Change:", min = -5, max = 5, value = 0.6, step = 0.05),
        sliderInput("ramp_start", "Ramp Start:", min = 0, max = 1, value = 0.3, step = 0.05),
        sliderInput("ramp_length", "Ramp Length:", min = 0, max = 1, value = .01),
        sliderInput("steepness", "Steepness:", min = -2, max = 2, value = 0.8, step = 0.1),
      ), 
      
      conditionalPanel(
        condition = "input.series_type == 'Linex'",
        sliderInput("amplitude", "amplitude:", min = -5, max = 5, value = 0.3, step = 0.05),
        sliderInput("x_min", "x_min:", min = -5, max = 100, value = 0.6, step = 0.05),
        sliderInput("scale", "scale:", min = 0, max = 1, value = 0.3, step = 0.05),
      ), 
      
      conditionalPanel(
        condition = "input.series_type == 'Gaussian'",
        sliderInput("amplitude", "amplitude:", min = -5, max = 5, value = 0.3, step = 0.05),
        sliderInput("centre", "centre:", min = -5, max = 100, value = 0.6, step = 0.05),
        sliderInput("width", "width:", min = -2, max = 10, value = 0.3, step = 0.05),
      ), 
    ),
    
    mainPanel(
      plotOutput("timeSeriesPlot")
    )
  )
)

