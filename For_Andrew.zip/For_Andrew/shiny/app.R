library(shiny)

# Source the UI and server files
source("For_Andrew/shiny/ui.R")
source("For_Andrew/shiny/server.R")

# Run the application
shinyApp(ui = ui, server = server)
